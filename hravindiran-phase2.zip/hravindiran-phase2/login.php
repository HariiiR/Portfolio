<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Process</title>
    <link rel="stylesheet" href="reset.css" title = "Default Style">
    <link rel="stylesheet" href="main.css" title = "Default Style">
</head>
<body>
    <div id="bar"><img src="logo4.png" alt="Haresh's Logo"></div>
    <aside id = "login">
        <form  action="addPost.php" method="POST">
            <?php 
                $servername = "localhost:3307";
                $username = "root";
                $password = "";
                $dbname = "ecs417";
                // gets the username and password from the form in login.html
                $email = $_POST["email"];
                $Password =$_POST["password"]; 
                // below connects to the datebase using the given servername, username,password and database name so we can access the database.
                $conn = new mysqli($servername, $username, $password, $dbname);
                //  selects the first name, last name, email, password from the users table where it equals to the given email and password from the user, if the username and password does not match with the information in the database, the website will show error.
                $sql = "SELECT firstName,lastName,email,password FROM USERS WHERE email ='".$email."' AND password='".$Password."'" ;
                $found= mysqli_query($conn,$sql);
                // if there is an email and password given by the user, the sql query should return 1 if it matches in the table, if not it will return 0 meaning nothing has matched in the sql table.
                if (mysqli_num_rows ($found)>0){
                    session_start(); // starts the session
                    while($row =mysqli_fetch_array($found)){
                        if (($email != 'ravi@gmail.com') && ($Password != 'Haresh05') ){ // other accounts' session id will be 1 to show the difference between the admin account and normal account
                        $number =1; 
                        $_SESSION['UserID'] =$number;
                        }

                        if (($email== 'ravi@gmail.com') && ($Password == 'Haresh05') ){ // admin account , this account can delete blogs and comments (extra feature)
                            $number =0;
                            $_SESSION['UserID'] =$number;
                            }

                        if (isset( $_SESSION['UserID'])){ //Once successfully logged in, website welcomes the user by their name and shows the addpost2.html
                            
                            echo "<aside id=loginandblog><h1> Welcome $row[0]</h1>";
                            include "addPost2.html";
                            
        
                           
                            
                        }
                    }
                }       
                else{
                    echo "Error: Check your email address and password"; // shows error when login and password are not matched by the sql table
                    }

                mysqli_close($conn); // closes database connection

             ?>
            
        </form>
    </aside>
    <footer>
        <p>Copyright © 2022 Haresh Ravindiran</p>
    </footer>

</body>
</html>