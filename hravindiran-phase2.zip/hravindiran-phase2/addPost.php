<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adding Blog</title>
</head>
<body>
    <?php 
         $servername = "localhost:3307";
         $username = "root";
         $password = "";
         $dbname = "ecs417";
         $blogTitle = $_POST["blogTitle"];
         $blogText =$_POST["blogText"];
         // below connects to the datebase using the given servername, username,password and database name so we can access the database.
         $conn = new mysqli($servername, $username, $password, $dbname);
         // sets the date and time to the Europe/London Time Zone
         date_default_timezone_set('Europe/London');
         // the current time and date is stored in the variables in a specific format 
         $date=date("j F Y");
         $time = date("H:i T");
         session_start(); //resumes existing session
      
        // adds the entered blog information from the user along with the time and date to the sql table
        $sql = "INSERT INTO BLOGS (blogTitle, blogText,date,time) VALUES ('$blogTitle', '$blogText','$date','$time')";


        $results= mysqli_query($conn,$sql); //does the query on the database
        mysqli_close($conn); // closes the database connection
        header('Location: viewBlog.php ');// redirects to the viewBlog.php so the user can see their blog post and the other blogs.
    ?>


</body>
</html>