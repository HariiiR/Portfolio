
<?php // Opens the main page and if the file is unreadable it will show error to the user.
$openfile = fopen("main_page.html", "r") ;
echo fread($openfile,filesize("main_page.html"));
fclose($openfile);

?>
