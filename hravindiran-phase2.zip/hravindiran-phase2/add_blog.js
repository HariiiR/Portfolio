document.querySelectorAll 
let form = document.querySelector('form'); // selects the html form element
let itemInput = document.querySelectorAll('input[type="text"]'); //selects all the input boxes
function executeEvent(e){
      var a= window.confirm("OK or CLEAR");
      if (a == false){ // if cancel is pressed for reset, the input boxes do not get cleared
        e.preventDefault();
      }
      else if (a == true){  // if ok is pressed for reset, the boxes are set to white as it could have been red from before when the user was trying to submit empty boxes.
        itemInput[0].style.backgroundColor='white';
        itemInput[1].style.backgroundColor='white';
      }
}

function executeEvent2(f){
    if ((itemInput[0].value.length == 0)){ //if blog title is empty
        f.preventDefault(); // prevents from submitting it 
        itemInput[0].style.backgroundColor='red'; // changes the box colour to red
    
     }
     if (itemInput[1].value.length == 0){ //if blog text is empty
        f.preventDefault(); // prevents from submitting it 
        itemInput[1].style.backgroundColor='red'; // changes the box colour to red
     }

}

form.addEventListener('reset',executeEvent); // adds the listener to the reset button in form and call the function executeEvent

form.addEventListener('submit',executeEvent2); // adds the listener to the submit button in form and call the function executeEvent2