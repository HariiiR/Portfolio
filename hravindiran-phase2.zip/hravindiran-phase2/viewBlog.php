<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Show Blog Table</title>
    <link rel="stylesheet" href="reset.css" title = "Default Style">
    <link rel="stylesheet" href="main.css" title = "Default Style">
</head>
<body>
<form action="logout.php" method="POST">
<aside id ="viewblog">
<?php 
        $servername = "localhost:3307";
         $username = "root";
         $password = "";
         $dbname = "ecs417";
         // below connects to the datebase using the given servername, username,password and database name so we can access the database.
         $conn = new mysqli($servername, $username, $password, $dbname);
         session_start(); // resumes the session
         echo "<div id=bar>
         <img src=logo4.png alt=Haresh's Logo>
         </div><hr>";

         if (isset($_GET['c'])&& isset($_GET['blogNumber'])){ // adds a comment to a specifc blog (extra feature). Gets the blogNumber and the comment from addComment.html 
            $UblogNumber = $_GET["blogNumber"];
            $comment =$_GET['c'];
            $sql = "UPDATE BLOGS SET comment = ('$comment') where (id LIKE ('$UblogNumber'))"; // sets the comment for the specifed blog number
            $found= mysqli_query($conn,$sql); //performs the query on the table
        }

         if (isset($_GET["month"])) // extra feature (view blogs by month) if the month is set , then an a sql query will be done, to show all the blogs from the specified month from the user
         {
            $month = $_GET["month"];
            $sql = "SELECT blogTitle, blogText,date,time,id,comment FROM BLOGS WHERE date LIKE '%$month%'";
            $found= mysqli_query($conn,$sql); 
       
         
            if (mysqli_num_rows ($found)>0){ //  if there are any blog posts in the sql table
                ($row =mysqli_fetch_all($found, MYSQLI_ASSOC)); // fetchs the information from the sql table as an associative array
                $column = array_column($row, 'id'); // gets the id column in the array
                array_multisort($column,SORT_DESC,$row);// then it sorts the array by the id column from highest id number to lowest id number (showing the latest blog post at the top)
            }
            

            if (isset($row)){ 
                foreach($row as $rows){ //prints the blog number, date,time ,blog Title , blog text and comment to the user by looping thru the rows
                    echo "<h5> Blog Post Number ",$rows['id'],"</h5>";
                    echo "<h5>",$rows['date'],", ",$rows['time'],"</h5>";
                    echo "<b>",$rows['blogTitle'],"</b>"," ","<br>",$rows['blogText'],"<br>";
                    echo "<i>",$rows['comment'],"</i>","<hr>";
                }

            }
            else{ // if no blogs stored in a specifed month, then the website will show No results
                echo "No results<br>";
            }
        }
         
         if (!isset($_GET["month"])){ //shows all the blogs from all time when month is not set by the user
            $sql = "SELECT blogTitle, blogText,date,time,id,comment FROM BLOGS"; // selects all the blog information,time,date,id,comment from the table blogs
            $found= mysqli_query($conn,$sql); // performs the sql query

       
            if (mysqli_num_rows ($found)>0){ //  if there are any blog posts in the sql table
                ($row =mysqli_fetch_all($found, MYSQLI_ASSOC)); // fetchs the information from the sql table as an associative array
                $column = array_column($row, 'id');  // gets the id column in the array
                array_multisort($column,SORT_DESC,$row); // then it sorts the array by the id column from highest id number to lowest id number (showing the latest blog post at the top)
            }
            else{ //no blogs stored at all, user will be redirected to login page
                header('Location: login.html');
            }
            
            foreach($row as $rows){ //prints the blog number, date,time ,blog Title , blog text and comment to the user by looping thru the rows
                echo "<h5> Blog Post Number ",$rows['id'],"</h5>";
                echo "<h5>",$rows['date'],", ",$rows['time'],"</h5>";
                echo "<b>",$rows['blogTitle'],"</b>"," ","<br>",$rows['blogText'],"<br>";
                echo "<i>",$rows['comment'],"</i>","<hr>";
            }
        }

        if (isset($_GET['selectC'])&& isset($_GET['blogNumber'])){ // (extra feature) Gets the specfied comment using blog number or specfied the whole blog entry using blog number from the form in deletePostsComments.html
            if ($_GET['selectC'] == "Blog"){ // if user wants to delete blog
                $UblogNumber = $_GET['blogNumber'];// gets the blogmumber
                $sql = "DELETE FROM BLOGS WHERE id ='$UblogNumber'"; // sql deletes the blog entry from the specifed blog number
                mysqli_query($conn,$sql); // performs the query
                
            }
            if ($_GET['selectC']== "Comment"){ // if user wants to delete comment only 
                
                $UblogNumber = $_GET['blogNumber']; // gets the blogmumber
                $sql = "UPDATE BLOGS SET comment = (null) where (id = ('$UblogNumber'))"; // sql updates the commment field as null for the specfied blog number
                mysqli_query($conn,$sql);  // performs the query
                
            }
            header('Location: viewBlog.php '); // redirects to  updated viewBlog.php
            

       
        
            ($row =mysqli_fetch_all($found, MYSQLI_ASSOC)); // fetchs the information from the sql table as an associative array
            $column = array_column($row, 'id'); // gets the id column in the array
            array_multisort($column,SORT_DESC,$row);  // then it sorts the array by the id column from highest id number to lowest id number (showing the latest blog post at the top)
            

            foreach($row as $rows){ //prints the blog number, date,time ,blog Title , blog text and comment to the user by looping thru the rows
                echo "<h5> Blog Post Number ",$rows['id'],"</h5>";
                echo "<h5>",$rows['date'],", ",$rows['time'],"</h5>";
                echo "<b>",$rows['blogTitle'],"</b>"," ","<br>",$rows['blogText'],"<br>";
                echo "<i>",$rows['comment'],"</i>","<hr>";
            }

        }

       
        
      
         
        if (isset ($_SESSION['UserID'])){ // if user is logged in, shows the log out and add Post button
            echo "<p>";
            echo "<button id=one> 
            <a href=logout.php>
            Log Out
            </a>
            </button><br><br>";
            echo "<button>
            <a href=addPost.html>
            Add Post 
            </a>
            </button>";

            echo "<br><br><button>
              <a href =addComment.html> Add Comment</a>
              </button>";

              if ($_SESSION['UserID']==0){ // if user is an admin account, shows the delete posts or comments button (extra feature)
            
                echo "<br><br><button>
                <a href=deletePostsComments.html>
                Delete Posts or Comments
                </a>
                </button>";
    
            }
        }
        if (!isset ($_SESSION['UserID'])){ // if user not logged in, when add Post or add Comment is clicked , the user will be redirected to the login page.
            echo "<button>
            <a href=login.html>
            Add Post 
            </a>
            </button>";
            
            echo "<br><br><button>
              <a href =login.html> Add Comment</a>
              </button>";

            echo "<br><br><button>
            <a href=index.php>
            Main Page
            </a>
            </button>";
        }

        
        // A button which goes to the getMonth.html where the user can choose the month and submit it.
        echo "<br><br><button>
        <a href =getMonth.html> Search Blogs by month</a>
        </button>";
        
        echo "<hr><footer>
        <p>Copyright © 2022 Haresh Ravindiran</p>
        </footer>";



        
    ?>

             
</aside>
</form>
</body>
</html>